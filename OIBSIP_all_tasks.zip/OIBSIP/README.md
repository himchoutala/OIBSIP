# OIBSIP — Data Analytics Internship (Oasis Infobyte)

**Name:** [your full name]  
**Track:** Data Analytics  
**LinkedIn:** [your profile link]

This repository contains my Data Analytics internship projects. Each project is in its own folder with a notebook, dataset, README and chart screenshots.

## Projects
| # | Task | Folder | Data | Key result |
|---|---|---|---|---|
| 1 | L1 · Cleaning Data | [`DataAnalytics-L1-DataCleaning`](DataAnalytics-L1-DataCleaning) | Synthetic messy dataset (generated) | 1,050 → 978 rows, 398 → 0 null cells, 50 duplicates removed |
| 2 | L1 · EDA on Retail Sales | [`DataAnalytics-L1-EDARetailSales`](DataAnalytics-L1-EDARetailSales) | Synthetic retail data (generated) | Discounts did not increase order size; Q4 ≈ 36% of revenue |
| 3 | L1 · Customer Segmentation | [`DataAnalytics-L1-Customer_Segmentation`](DataAnalytics-L1-Customer_Segmentation) | Real (customer demographics) | 5 segments via K-Means (K = 5); no RFM possible without transactions |
| 4 | L2 · House Price Prediction | [`DataAnalytics-L2-HousePricePrediction`](DataAnalytics-L2-HousePricePrediction) | Real (Boston Housing) | Linear R² 0.684; log-price model 0.757 |
| 5 | L2 · Wine Quality Prediction | [`DataAnalytics-L2-WineQualityPrediction`](DataAnalytics-L2-WineQualityPrediction) | Real (UCI white wine) | Random Forest 59.1% accuracy; duplicates were leaking data |
| 6 | L1 · Sentiment Analysis | [`DataAnalytics-L1-SentimentAnalysis`](DataAnalytics-L1-SentimentAnalysis) | [dataset name] | [best model and its score] |
| 7 | L2 · Fraud Detection | [`DataAnalytics-L2-FraudDetection`](DataAnalytics-L2-FraudDetection) | [dataset name] | [best model: recall / precision / AUC] |

## Tech stack
Python · pandas · numpy · scikit-learn · matplotlib · seaborn · Jupyter Notebook

## Notes on data and honesty
- Projects 1 and 2 use **synthetic datasets that I generated** to contain realistic problems; the README of each says so.
- Project 3 does not include RFM analysis because the dataset has no transaction history (explained in its README).
- Project 4 excludes the `B` column (derived from neighbourhood racial composition) for ethical reasons.

## Running a project
```bash
pip install pandas numpy matplotlib seaborn scikit-learn jupyter
cd <project-folder>
jupyter notebook
```
