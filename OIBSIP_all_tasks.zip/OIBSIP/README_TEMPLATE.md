# Data Analytics · [Level X] · [Task N] — [Task title]

**Oasis Infobyte Internship Program (OIBSIP)** · Track: Data Analytics

## Objective
[One or two sentences from the task card.]

## Dataset
[Name, source (e.g. Kaggle/UCI), number of rows and columns, what the target or main variable is.]

## Files
| File | Description |
|---|---|
| `[notebook name].ipynb` | Full analysis with written observations |
| `[data file]` | Dataset |
| `screenshots/` | Exported charts |

## Tech Stack
[Python · pandas · scikit-learn · ... — copy from the task card]

## Approach
1. [Step 1]
2. [Step 2]
3. [...]

## Results
[A small table with your REAL numbers from running the notebook, e.g. accuracy / F1 / R² per model.]

## Key findings
- [Finding 1 — with a number]
- [Finding 2 — with a number]
- [Finding 3 — with a number]

## Limitations
[What the model or analysis cannot do; data caveats. Be specific and honest.]

## How to run
```bash
pip install pandas numpy matplotlib seaborn scikit-learn jupyter
jupyter notebook [notebook name].ipynb
```

## Demo
- Demo video / LinkedIn post: [paste your link here]
